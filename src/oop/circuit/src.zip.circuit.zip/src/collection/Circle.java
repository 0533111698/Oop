package collection;

public class Circle implements Comparable<Circle> {
    private int radius;
    private String color;

    public Circle(int radius, String color) {
        setRadius(radius);
        this.color = color;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }


    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return
                "radius=" + radius +
                ", color='" + color + '\'';
    }




    @Override
    public int compareTo(Circle o) {
        return (int) getRadius()*1000-(int) o.getRadius()*1000;
    }
}
