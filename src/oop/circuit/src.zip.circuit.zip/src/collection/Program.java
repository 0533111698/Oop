package collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Program {
    public static void main(String[] args) {
        ArrayList<Integer>numbers=new ArrayList<>();
        numbers.add(52);
        numbers.add(10);
        numbers.add(98);
        System.out.println(numbers);
        Collections.sort(numbers);
        System.out.println(numbers);
        ArrayList<String>names=new ArrayList<>();
        names.add("aba");
        names.add("saba");
        names.add("TOM");
        names.add("miri");
        Collections.sort(names);
        System.out.println(names);

    }
}
