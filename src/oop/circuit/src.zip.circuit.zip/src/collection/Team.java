package collection;

public class Team implements Comparable<Team> {
    private String name,color;
    private int numOfPlayers;

    public Team(String name, String color, int numOfPlayers) {
        this.name = name;
        this.color = color;
        this.numOfPlayers = numOfPlayers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNumOfPlayers() {
        return numOfPlayers;
    }

    public void setNumOfPlayers(int numOfPlayers) {
        this.numOfPlayers = numOfPlayers;
    }

    @Override
    public String toString() {
        return
                "name='" + name + '\'' +
                ", color='" + color + '\'' +
                ", numOfPlayers=" + numOfPlayers
                ;
    }

    @Override
    public int compareTo(Team other) {
//        if (this.numOfPlayers<other.getNumOfPlayers())
//        return -1;
//        if (this.numOfPlayers>other.getNumOfPlayers())
//            return 1;
//        return 0;
//    }
        return this.getName().compareTo(other.getName())*-1;
    }
}
