package collection;

import java.util.ArrayList;
import java.util.Collections;

public class ProgramTeam {
    public static void main(String[] args) {
        ArrayList<Team>teams=new ArrayList<>();
        teams.add(new Team("Malki","red",6));
        teams.add(new Team("Chani","blue",7));
        teams.add(new Team("rhag","pink",4));
        System.out.println(teams);
        Collections.sort(teams,new MyTeamComparator());
        System.out.println(teams);
    }
}
