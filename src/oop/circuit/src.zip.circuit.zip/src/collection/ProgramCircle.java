package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ProgramCircle {
    public static void main(String[] args) {
//        String []colors={"red","yellow","pink"};
//        ArrayList<Circle>circles=new ArrayList<>();
//        int radius=(int)(Math.random()*91+10);
//        while (radius<=90){
//            circles.add(new Circle(radius,colors[(int) (Math.random()*3)]));
//            radius=(int)(Math.random()*91+10);
//        }
//        Collections.sort(circles);
//        for (Circle x:circles) {
//            System.out.println(x);
//            System.out.println(Math.PI*Math.pow(x.getRadius(),2.0));
        String []colors={"red","yellow","pink"};
        ArrayList<String>words=new ArrayList<>();
        int radius=(int)(Math.random()*91+10);
        Scanner scanner=new Scanner(System.in);
        for (int i = 0; i <5; i++) {
            System.out.println("Enter a word");
            words.add(scanner.nextLine());
        }
        Collections.sort(words);
        for (String x:words) {
            System.out.println(x);


        }
    }

}
