package api.bird;

public interface IConsumable {
   String describeTaste();
    boolean isMainCourse();
}
