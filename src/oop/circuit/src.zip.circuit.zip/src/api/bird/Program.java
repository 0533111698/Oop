package api.bird;

public class Program {
    public static void main(String[] args) {
        Cow cow=new Cow();
        System.out.println(cow.describeTaste());
    }
}
