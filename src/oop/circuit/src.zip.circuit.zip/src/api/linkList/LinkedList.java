package api.linkList;

public class LinkedList {
    private Node head;

}
