package api.linkList;

public class Node <T>{
    private T value;
    private Node<T>next;

}
