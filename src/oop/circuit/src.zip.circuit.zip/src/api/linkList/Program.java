package api.linkList;

public class Program {
    public static void main(String[] args) {
        Node<String>node1=new Node<>();
    }
}
