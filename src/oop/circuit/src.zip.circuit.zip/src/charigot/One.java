//package charigot;
//
//import java.util.ArrayList;
//import java.util.InputMismatchException;
//import java.util.Scanner;
//
//public class One {
//    public static void main(String[] args) {
//        ArrayList<Double>myList=new ArrayList<>();
//        int choice=0;
//        while (choice!=5){
//            try{
//            Scanner scanner=new Scanner(System.in);
//            choice=scanner.nextInt();
//            System.out.println("choose:1>add new number");
//            System.out.println("choose 2 to delete");
//            System.out.println("choose 3 sort and print");
//            System.out.println("choose 4 to print");
//            System.out.println("choose 5 to exit");
//                switch (choice){
//                    case 1:
//                        while(true){
//                            try {
//
//                            }
//                        }
//                        System.out.println("please enter new number");
//                        double num=scanner.nextDouble();
//                        myList.add(num);
//                        break;
//                    case 2:
//                        System.out.println("please enter index");
//                        int ind=scanner.nextInt();
//                        myList.add();
//                        break;
//                    case 3:
//                        break;
//                    case 4:
//                        break;
//                    case 5:
//                        System.out.println("good bye");
//                        break;
//                    default:
//                        System.out.println("you have a mistake,choose enter");
//                        break;
//
//                }
//            }catch (InputMismatchException e){
//                System.out.println("enter numbers only");
//            }
//
//        }
//
//
//    }
//}
