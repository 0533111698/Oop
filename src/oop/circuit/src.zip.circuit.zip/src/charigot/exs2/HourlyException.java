package charigot.exs2;

public class HourlyException extends Exception {
    public HourlyException(String message) {
        super(message);
    }
}
