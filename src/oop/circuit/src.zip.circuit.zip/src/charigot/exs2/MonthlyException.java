package charigot.exs2;

public class MonthlyException extends Exception{
    public MonthlyException(String message) {
        super(message);
    }
}
