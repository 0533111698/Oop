package charigot.exs2;

import oop.ClassesInClass.Employee;

public class ProgramEmployee {
    public static void main(String[] args) {
        Employee2[]employee2s=new Employee2[4];
        for (int i = 0; i <employee2s.length; i++) {
            try {
                employee2s[i]=new Employee2();
            } catch (HourlyException e) {
                throw new RuntimeException(e);
            } catch (MonthlyException e) {
                throw new RuntimeException(e);
            }
            employee2s[i].setName("employee"+(i+1));
            System.out.println(employee2s[i].getName());
            try {
                employee2s[i].setHourlyWage((Math.random() * 20) +20);
            } catch (HourlyException e) {
                System.out.println(e.getMessage());
            }
            System.out.println(employee2s[i].getHourlyWage());



        }

    }
}
