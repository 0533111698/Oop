package charigot.exs2;

public class Employee2 {
    private String name;
    private double hourlyWage;
    private double monthlyWorkingHours;

    public Employee2() throws HourlyException, MonthlyException {
        setName(name);
        setHourlyWage(hourlyWage);
        setMonthlyWorkingHours(monthlyWorkingHours);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage)throws HourlyException {
        if (hourlyWage<29.12)
        this.hourlyWage = hourlyWage;
        else throw new HourlyException("Invalid hourlyWage!");
    }

    public double getMonthlyWorkingHours() {
        return monthlyWorkingHours;
    }

    public void setMonthlyWorkingHours(double monthlyWorkingHours)throws MonthlyException {
        if (monthlyWorkingHours>0&&monthlyWorkingHours<=40)
        this.monthlyWorkingHours = monthlyWorkingHours;
        else throw new MonthlyException("Invalid monthlyWorkingHours");
    }
}
