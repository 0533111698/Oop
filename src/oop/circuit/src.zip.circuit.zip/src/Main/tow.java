package Main;

import java.util.Random;
import java.util.Scanner;

public class tow {
    public static void main(String[] args) {
        //תרגיל 1
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("please enter a number");
//        int num=scanner.nextInt();
//        if (num%2==0) {
//            System.out.println("double number");
//        }else System.out.println("Not double number");
//
//תרגיל 2
//     System.out.println("Please enter 2 numbers");
//     int num1=scanner.nextInt();
//     int num2=scanner.nextInt();
//     if (num2==num1) {
//         System.out.println("the numbers are the same");
//     }else System.out.println("The numbers are not the same");
//
        //תרגיל 3
//        System.out.println("Please enter a number");
//        int num=scanner.nextInt();
//        if (num>=0){
//            System.out.println(num = num);
//        }else System.out.println(num*(-1));
        //תרגיל 4
//        System.out.println("How many phone calls did you do?");
//        int num=scanner.nextInt();
//        System.out.println("How much money one phone call costs? ");
//        double cost=scanner.nextDouble();
//        double result=(num*cost);
//        if (result>500) {
//            System.out.println("Chatterbox,the cost is: " + result);
//        }else System.out.println(result);
        //תרגיל 5
//        System.out.println("Please insert 2 numbers");
//        int max=scanner.nextInt();
//        int den=scanner.nextInt();
//        if (max%den==0)System.out.println(den+"  divides "+max);
//        else System.out.println(den+"  dividesn't "+max);
        //תרגיל 6
//        System.out.println("How many beats?");
//        int beats =scanner.nextInt();
//        if
//            (beats<100)
//            System.out.println((0.4 * beats + 75) * 1.17);
//       else{System.out.println((0.3*beats+75)*1.17);
//
//    }
        //תרגיל 7
//        System.out.println("Please enter 3 numbers");
//        int a=scanner.nextInt();
//        int b=scanner.nextInt();
//        int c=scanner.nextInt();
//        if (a>b&&a>c)System.out.println(a);
//        else if (b>a&&b>c) {System.out.println(b);
//        }else System.out.println(c);
//        System.out.println("please enter a number");
//        int num=scanner.nextInt();
//        if (num>0)System.out.println("possitive");
//        else if (num<0) {System.out.println("negative");
//        }else System.out.println("0");
////תרגיל 8
        //מערכים
//        char[]arr={'a','b','c','a','b','d','r',};
//        boolean
//        if (arr="")
//
//        Random r=new Random();
//        int[] nums=new int[10];
//
//        for (int i = 0; i <nums.length; i++) {
//            nums[i]=(int) (Math.random()*10)+1;
//            System.out.println(nums[i]);
//        }
//        int[]arr={1,2,3,1,2,3,3,2,1,9,5,1,1,9};
//        int counter3=0;
//        int counter1=0;
//        int counter25=0;
//        for (int i = 0; i <arr.length; i++) {
//            if (arr[i]==3)counter3++;
//            else if (arr[i]==1) {
//                counter1++;
//            } else if (arr[i]==2||arr[i]==5) {
//           counter25++;
//            }
//
//        }System.out.println(counter3);
//        System.out.println(counter1);
//        System.out.println(counter25);

        //עצרת
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("num");
//        int nun=scanner.nextInt();
//        int assembly=1;
//        for (int i = 0; i <nun; i++) {
//           assembly=(assembly*(i+1));
//
//        }System.out.println(assembly);
//מספרים עוקבים
//    Scanner scanner=new Scanner((System.in));
//    System.out.println("Please insert 3 numbers");
//    int num1=scanner.nextInt();
//        int num2=scanner.nextInt();
//        int num3=scanner.nextInt();
//        if (num1+1==num2&&num1+2==num3||num1+2==num2&&num1+1==num3)
//        {
//            System.out.println("consecutive numbers");
//        }else if
//            (num2 + 1 == num1 && num2 + 2 == num3 || num2 + 2 == num3 && num2 + 1 == num1) {
//            System.out.println("consecutive numbers");
//        } else if
//        (num3+1==num2&&num3+2==num1||num3+2==num2||num3+1==num1){
//            System.out.println("consecutive numbers");
//        }else {
//            System.out.println("not consecutive numbers");
//        }
//        }
        //האם זה ספרה
        Scanner scanner=new Scanner(System.in);
//        System.out.println("Please a singular char");
//        char ch=scanner.next().charAt(0);
//        if (ch*1==ch)
//            System.out.println("it's a number");
//        else
//            System.out.println("it's not a number");
//
//ציון מבחן
//        System.out.println("please enter a grade");
//        int grade=scanner.nextInt();
//        if (grade>0&&grade<56){
//            System.out.println("fails");
//        } else if (grade>55&&grade<71) {
//            System.out.println("weak");
//        } else if (grade>70&&grade<85) {
//            System.out.println("medium");
//        } else if (grade>84&&grade<91) {
//            System.out.println("good");
//        } else if (grade>90&&grade<101) {
//            System.out.println("excellent!");
//        }else {
//            System.out.println("your answer is not supported please enter again ");
//        }
//        System.out.println("Please enter 3 numbers");
//        int a=scanner.nextInt();
//        int b=scanner.nextInt();
//        int c=scanner.nextInt();
//        if (a>b&&b>c){
//            System.out.println(a+" "+b+" "+c);
//        } else if (a>c&&c>b) {
//            System.out.println(a+" "+c+" "+b);
//        } else if (b>a&&a>c) {
//            System.out.println(b+" "+a+" "+c);
//        } else if (b>c&&c>a) {
//            System.out.println(b+" "+c+" "+a);
//        } else if (c>a&&a>b) {
//            System.out.println(c+" "+a+" "+b);
//        }else System.out.println(c+" "+b+" "+a);
//        int sum=0;
//        int average=0;
//        for (int i = 0; i <10; i++) {
//            System.out.println("Please enter a number");
//            int num=scanner.nextInt();
//            sum+=num;
//        }average=(sum/10);
//        System.out.println(average);
//System.out.println("please insert a num");
//int num=scanner.nextInt();
//        int max=num;
//        int min=num;
//        for (int i = 0; i <99; i++) {
//            System.out.println("please enter a num");
//            int a=scanner.nextInt();
//            if (a>max)max=a;
//            else if (a<min)min=a;
//
//
//        }System.out.println("the biggest number"+max);
//        System.out.println("the smalest number"+min);
//מכפלה ללא שימוש בפעולת כפל
//        System.out.println("please enter 2 numbers");
//        int a=scanner.nextInt();
//        int b=scanner.nextInt();
//        int sum=0;
//        for (int i = 0; i <b; i++) {
//        sum+=a;
//
//        }System.out.println(sum);
        //הצגת ספרות
//        System.out.println("please enter a number");
//        int num=scanner.nextInt();
//        while (num>0){
//            System.out.println(num%10);
//            num/=10;
//

//        }
//הדפסת עצרת
//        System.out.println("please insert a number");
//        int num=scanner.nextInt();
//        int assembly=1;
//        for (int i = 0; i <num; i++) {
//        assembly=assembly*(i+1);
//        }System.out.println(assembly);
//
//         System.out.println("Please enter 2 numbers");
//         int a=scanner.nextInt();
//         int b=scanner.nextInt();
//         int max=0;
//         int sum=0;
//         if (b<0){max=(b*(-1));
//         }else {max=b;}
//        for (int i = 0; i <max; i++) {
//          sum+=a;
//
//
//        }if (b<0){
//            sum=sum*(-1);}
//            System.out.println(sum);
//System.out.println("please enter a number");
//int num=scanner.nextInt();
//        for (int i = 0; i<num; i++) {
//            System.out.println(" ");
//            for (int j = (i+1); j <=num; j++)
//            System.out.print(j);
//
//
//
//
//        }
//        System.out.println("please enter a number");
//        int num=scanner.nextInt();
//        for (int i =num; i>0; i--) {
//            System.out.println(" ");
//            for (int j = 1; j <= i; j++)
//                System.out.print(j);
//        }
//        for (int i = 1; i <21; i++) {
//            System.out.println(" ");
//            for (int j = 1; j <21; j++) {
//                System.out.print(i*j+" ");
//            }
//        }
        //להדפיס מס הפוך
//        int myNwename=0;
//        System.out.println("please enter a number");
//        int num=scanner.nextInt();
//        while (num!=0){
//           myNwename=myNwename*10+num%10;
//           num/=10;
//
//        }System.out.println(myNwename);

//        for (int i = 1; i <=50; i++) {
//        if (i%3==0||i%5==0)System.out.println(i);
//        }

        for (int i = 0; i <3; i++) {
            System.out.println("please Insert a num");
            int num=scanner.nextInt();
            int j=0;
            while (num>0) {
                num = num / 10;
                j++;
            }
            System.out.println(j);
        }
        }
}
