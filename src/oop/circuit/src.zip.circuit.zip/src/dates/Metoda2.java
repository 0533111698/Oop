package dates;

public class Metoda2 {
    public static void main(String[] args) {
//        womanTired("Malki",'k');
//
//    }

//
//    private static void womanTired(String text,char chr){
//        int counter=0;
//        boolean found=true;
//        for (int t = 0; t <text.length(); t++) {
//            char x=text.charAt(0);
//            if (==chr){
//                found=true;
//                counter++;
//
//            }else {found=false;}
//
//
//
//        }System.out.println(found? counter: "not found");
//
    }
}
