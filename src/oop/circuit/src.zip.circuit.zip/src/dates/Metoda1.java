package dates;

public class Metoda1 {
    public static void main(String[] args) {
        naim("Malki");
        naim("Gefner");

    }


    public static void naim(String firstName){
        System.out.print(firstName+" ");

    }
}
