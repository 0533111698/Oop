package nisaion;

public class Nisaion {
    public static void main(String[] args) {

        int[] nums1=new int[15];
        for (int i = 0; i < nums1.length; i++) {
            nums1[i]=(int) (Math.random()*10);
            System.out.print(nums1[i]+" ");
        }
        System.out.println("\n"+"-------");
        int[]nums2=new int[15];
        for (int i = 0; i < nums2.length; i++) {
            nums2[i]=(int) (Math.random()*10);
            System.out.print(nums2[i]+" ");

        }
        System.out.println("\n"+"-------");

        int max=0;
        int temp=0;
        for (int i = 0; i < nums1.length-2; ) {
            temp=nums1[i]*100+nums1[i+1]*10+nums1[i+2];
            if (temp>max)
                max=temp;
            i++;
        }
        System.out.println("\n"+" The biggest number is: "+max);

        int[]distinct=new int[10];
        for (int i = 0; i < distinct.length; i++) {
            distinct[i]=(-1);
            System.out.print(distinct[i]+" ");

        }
        System.out.print("\n");
        int x=0;
        for (int i = 0; i < nums1.length; i++) {
            boolean isEqual=true;
            for (int j = 0; j < nums2.length; j++) {
                if (nums1[i]==nums2[j]){
                    isEqual=false;
                    break;}
            }
            if (isEqual==true){
                for (int j = 0; j <=x; j++) {
                    if (nums1[i]!=distinct[j]){
                        isEqual=true;
                    }else{ isEqual=false;
                        break;}
                }if (isEqual==true){
                    distinct[x]=nums1[i];
                    System.out.print(distinct[x]);
                    x++;
                }

            }
        }
        for (int i = 0; i < nums2.length; i++) {
            boolean isEqual=true;
            for (int j = 0; j < nums1.length; j++) {
                if (nums2[i]==nums1[j]){
                    isEqual=false;
                    break;}

            }
            if (isEqual==true){
                for (int j = 0; j <=x; j++) {
                    if (nums2[i]!=distinct[j]){
                        isEqual=true;
                    }else{ isEqual=false;
                        break;}
                }if (isEqual==true){
                    distinct[x]=nums2[i];
                    System.out.print(distinct[x]);
                    x++;
                }
            }
        }
        System.out.println("\n"+"------");
        for (int i = 0; i < distinct.length; i++) {
            System.out.print(distinct[i]+" ");

        }
        int newNum=0;
        for (int i =x-1; i>-1; i--) {
            newNum=newNum*10+distinct[i];

        }
        System.out.println("-----");
        System.out.println(newNum);




    }



}
