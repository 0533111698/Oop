import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("please insert 3 numbers");
//        int x=scanner.nextInt();
//        int y=scanner.nextInt();
//        int z=scanner.nextInt();
//        if (x+1==y&&x+2==z||x+2==y&&x+1==z){
//            System.out.println();
//        }
//

    }
}