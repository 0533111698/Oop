package oop;

public class Program {
    public static void main(String[] args) {
        Order ords=new Order("Oil", 5,8.90);
        ords.printOrder();
    }
}
