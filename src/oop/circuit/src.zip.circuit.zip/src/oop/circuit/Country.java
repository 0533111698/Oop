package oop.circuit;

public enum Country {
    Israel,Luv,Tunis,Italy
}
