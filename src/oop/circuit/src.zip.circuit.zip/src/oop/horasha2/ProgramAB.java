package oop.horasha2;

public class ProgramAB {
    public static void main(String[] args) {
        Bird b1=new Bird("Birdi","xl",89,9);
        System.out.println(b1);
        b1.printFly();
    }
}
