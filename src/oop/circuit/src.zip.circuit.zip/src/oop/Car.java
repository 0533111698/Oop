package oop;

public class Car {
int year;
String colour;


}
