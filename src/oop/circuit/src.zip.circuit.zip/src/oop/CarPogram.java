package oop;

public class CarPogram {
    public static void main(String[] args) {
        Car danscar=new Car();


    }
}
