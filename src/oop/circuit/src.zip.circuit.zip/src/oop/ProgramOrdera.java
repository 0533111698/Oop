package oop;

public class ProgramOrdera {
    public static void main(String[] args) {

    }
    public void oven(){
        Ordera ovens=new Ordera("toster oven",2,450);
     ovens.printordera();

    }
    public void oil(){
        Ordera a=new Ordera("oil",5,8.9);
        a.printordera();

    }
}
