//package oop.shapes2;
//
//public class Hexagon extends Shape{
//    private int numOfends;
//
//    public Hexagon(String color, int x, int y, int numOfends) {
//        super(color, x, y);
//        this.numOfends = numOfends;
//    }
//
//    public int getNumOfends() {
//        return numOfends;
//    }
//
//    public void setNumOfends(int numOfends) {
//        this.numOfends = numOfends;
//    }
//
//    @Override
//    public String toString() {
//        return "Hexagon{" +
//                "numOfends=" + numOfends +
//                '}';
//    }
//}
