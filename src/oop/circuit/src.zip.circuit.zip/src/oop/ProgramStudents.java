package oop;

public class ProgramStudents {
    public static void main(String[] args) {
        Students s1=new Students("Malki","Gefner","a05331111698@gmail.com",
                100,99,97);
        s1.printStudents();
        Students s2=new Students("Chani", "Daitsh", "c054@gmil.com",
                95,95,100);
        s2.printStudents();
    }


}
