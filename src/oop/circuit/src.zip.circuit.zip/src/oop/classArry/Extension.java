package oop.classArry;

public enum Extension {
    jpg,docx,xlsx,com,mp3,csv
}
