//package oop.exs3;
//
//import oop.exs3.Note;
//
//public class Group {
//    private String name;
//    private int amount=Note.getNumOfNotes();
//
//}
