package oop.exs3;

public enum Status {
    open,closedSexcesfuly

}
