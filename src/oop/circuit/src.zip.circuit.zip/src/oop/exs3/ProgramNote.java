package oop.exs3;

public class ProgramNote {
    public static void main(String[] args) {
        Note note1=new Note("ANIMALS", "V,jiiioino",21/12/2022,Status.open);

    }
}
