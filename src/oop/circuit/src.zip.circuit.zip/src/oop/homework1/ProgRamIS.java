package oop.homework1;

public class ProgRamIS {
    public static void main(String[] args) {
        Iphone iphone1 =new Iphone("BLA","GLA",18,5);
        iphone1.printIphone();
        System.out.println("-----");
        Iphone iphone2=new Iphone(",kjmklh","khgbiy",98,8);
        iphone2.printIphone();
    }

}
