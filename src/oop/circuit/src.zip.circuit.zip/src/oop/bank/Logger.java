package oop.bank;

import java.util.ArrayList;

public class Logger {
    private String nameDriver;   protected static ArrayList<Log>logs;

    public Logger(String nameDriver) {
        this.nameDriver = nameDriver;
    }
}
