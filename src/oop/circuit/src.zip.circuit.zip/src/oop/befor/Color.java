package oop.befor;

public enum Color {
    yellow,red,blue,green
}
