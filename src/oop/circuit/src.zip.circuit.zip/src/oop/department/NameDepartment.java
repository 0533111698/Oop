package oop.department;

public enum NameDepartment {
    Sales,Finance,Administration,Engineering,Marketing
}
