package oop.malki;

public enum Profession {
    math,chemistry,geography,literature,physics,sports

}
