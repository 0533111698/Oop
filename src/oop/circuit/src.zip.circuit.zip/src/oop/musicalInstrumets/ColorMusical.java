package oop.musicalInstrumets;

public enum ColorMusical {
    brown,white,black,red;
}
