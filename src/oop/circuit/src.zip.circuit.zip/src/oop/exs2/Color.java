package oop.exs2;

public enum Color {
    black,blue,red
}
