package oop.horasha;

public class ProgramPE {
    public static void main(String[] args) {
        Worker work1=new Worker("MALKI",26,315747600,"Maale",5);
        work1.printWorker();
    }
}
